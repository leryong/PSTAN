import cv2
import numpy as np
import pdb
import argparse
import lpips
loss_fn = lpips.LPIPS(net='vgg', version=0.1)
loss_fn.cuda()

from basicsr.metrics.metric_util import reorder_image, to_y_channel
from piq import DISTS

def calculate_psnr_out_gt(img1,
                   img2,
                   img3,
                    lq_path,
                   crop_border,
                   input_order='HWC',
                   test_y_channel=False):
    """Calculate PSNR (Peak Signal-to-Noise Ratio).

    Ref: https://en.wikipedia.org/wiki/Peak_signal-to-noise_ratio

    Args:
        img1 (ndarray): Images with range [0, 255].
        img2 (ndarray): Images with range [0, 255].
        crop_border (int): Cropped pixels in each edge of an image. These
            pixels are not involved in the PSNR calculation.
        input_order (str): Whether the input order is 'HWC' or 'CHW'.
            Default: 'HWC'.
        test_y_channel (bool): Test on Y channel of YCbCr. Default: False.

    Returns:
        float: psnr result.
    """
    # pdb.set_trace()
    assert img1.shape == img2.shape, (
        f'Image shapes are differnet: {img1.shape}, {img2.shape}.')
    if input_order not in ['HWC', 'CHW']:
        raise ValueError(
            f'Wrong input_order {input_order}. Supported input_orders are '
            '"HWC" and "CHW"')
    img1 = reorder_image(img1, input_order=input_order)
    img2 = reorder_image(img2, input_order=input_order)
    img1 = img1.astype(np.float64)
    img2 = img2.astype(np.float64)

    if crop_border != 0:
        img1 = img1[crop_border:-crop_border, crop_border:-crop_border, ...]
        img2 = img2[crop_border:-crop_border, crop_border:-crop_border, ...]

    if test_y_channel:
        img1 = to_y_channel(img1)
        img2 = to_y_channel(img2)

    mse = np.mean((img1 - img2)**2)
    if mse == 0:
        return float('inf')
    return 20. * np.log10(255. / np.sqrt(mse))

def calculate_psnr_in_gt(img1,
                   img2,
                   img3,
                   lq_path,
                   crop_border,
                   input_order='HWC',
                   test_y_channel=False):
    """Calculate PSNR (Peak Signal-to-Noise Ratio).

    Ref: https://en.wikipedia.org/wiki/Peak_signal-to-noise_ratio

    Args:
        img1 (ndarray): Images with range [0, 255].
        img2 (ndarray): Images with range [0, 255].
        crop_border (int): Cropped pixels in each edge of an image. These
            pixels are not involved in the PSNR calculation.
        input_order (str): Whether the input order is 'HWC' or 'CHW'.
            Default: 'HWC'.
        test_y_channel (bool): Test on Y channel of YCbCr. Default: False.

    Returns:
        float: psnr result.
    """
    # pdb.set_trace()
    assert img3.shape == img2.shape, (
        f'Image shapes are differnet: {img3.shape}, {img2.shape}.')
    if input_order not in ['HWC', 'CHW']:
        raise ValueError(
            f'Wrong input_order {input_order}. Supported input_orders are '
            '"HWC" and "CHW"')
    img3 = reorder_image(img3, input_order=input_order)
    img2 = reorder_image(img2, input_order=input_order)
    img3 = img3.astype(np.float64)
    img2 = img2.astype(np.float64)

    if crop_border != 0:
        img3 = img3[crop_border:-crop_border, crop_border:-crop_border, ...]
        img2 = img2[crop_border:-crop_border, crop_border:-crop_border, ...]

    if test_y_channel:
        img3 = to_y_channel(img3)
        img2 = to_y_channel(img2)

    mse = np.mean((img3 - img2)**2)
    if mse == 0:
        # return float('inf')
        print('path: ', lq_path,)
    return 20. * np.log10(255. / np.sqrt(mse))

def _ssim(img1, img2):
    """Calculate SSIM (structural similarity) for one channel images.

    It is called by func:`calculate_ssim`.

    Args:
        img1 (ndarray): Images with range [0, 255] with order 'HWC'.
        img2 (ndarray): Images with range [0, 255] with order 'HWC'.

    Returns:
        float: ssim result.
    """

    C1 = (0.01 * 255)**2
    C2 = (0.03 * 255)**2

    img1 = img1.astype(np.float64)
    img2 = img2.astype(np.float64)
    kernel = cv2.getGaussianKernel(11, 1.5)
    window = np.outer(kernel, kernel.transpose())

    mu1 = cv2.filter2D(img1, -1, window)[5:-5, 5:-5]
    mu2 = cv2.filter2D(img2, -1, window)[5:-5, 5:-5]
    mu1_sq = mu1**2
    mu2_sq = mu2**2
    mu1_mu2 = mu1 * mu2
    sigma1_sq = cv2.filter2D(img1**2, -1, window)[5:-5, 5:-5] - mu1_sq
    sigma2_sq = cv2.filter2D(img2**2, -1, window)[5:-5, 5:-5] - mu2_sq
    sigma12 = cv2.filter2D(img1 * img2, -1, window)[5:-5, 5:-5] - mu1_mu2

    ssim_map = ((2 * mu1_mu2 + C1) *
                (2 * sigma12 + C2)) / ((mu1_sq + mu2_sq + C1) *
                                       (sigma1_sq + sigma2_sq + C2))
    return ssim_map.mean()


def calculate_ssim_out_gt(img1,
                   img2,
                   img3,
                    lq_path,
                   crop_border,
                   input_order='HWC',
                   test_y_channel=False):
    """Calculate SSIM (structural similarity).

    Ref:
    Image quality assessment: From error visibility to structural similarity

    The results are the same as that of the official released MATLAB code in
    https://ece.uwaterloo.ca/~z70wang/research/ssim/.

    For three-channel images, SSIM is calculated for each channel and then
    averaged.

    Args:
        img1 (ndarray): Images with range [0, 255].
        img2 (ndarray): Images with range [0, 255].
        crop_border (int): Cropped pixels in each edge of an image. These
            pixels are not involved in the SSIM calculation.
        input_order (str): Whether the input order is 'HWC' or 'CHW'.
            Default: 'HWC'.
        test_y_channel (bool): Test on Y channel of YCbCr. Default: False.

    Returns:
        float: ssim result.
    """

    assert img1.shape == img2.shape, (
        f'Image shapes are differnet: {img1.shape}, {img2.shape}.')
    if input_order not in ['HWC', 'CHW']:
        raise ValueError(
            f'Wrong input_order {input_order}. Supported input_orders are '
            '"HWC" and "CHW"')
    img1 = reorder_image(img1, input_order=input_order)
    img2 = reorder_image(img2, input_order=input_order)
    img1 = img1.astype(np.float64)
    img2 = img2.astype(np.float64)

    if crop_border != 0:
        img1 = img1[crop_border:-crop_border, crop_border:-crop_border, ...]
        img2 = img2[crop_border:-crop_border, crop_border:-crop_border, ...]

    if test_y_channel:
        img1 = to_y_channel(img1)
        img2 = to_y_channel(img2)

    ssims = []
    for i in range(img1.shape[2]):
        ssims.append(_ssim(img1[..., i], img2[..., i]))
    return np.array(ssims).mean()

def calculate_ssim_in_gt(img1,
                   img2,
                   img3,
                    lq_path,
                   crop_border,
                   input_order='HWC',
                   test_y_channel=False):
    """Calculate SSIM (structural similarity).

    Ref:
    Image quality assessment: From error visibility to structural similarity

    The results are the same as that of the official released MATLAB code in
    https://ece.uwaterloo.ca/~z70wang/research/ssim/.

    For three-channel images, SSIM is calculated for each channel and then
    averaged.

    Args:
        img1 (ndarray): Images with range [0, 255].
        img2 (ndarray): Images with range [0, 255].
        crop_border (int): Cropped pixels in each edge of an image. These
            pixels are not involved in the SSIM calculation.
        input_order (str): Whether the input order is 'HWC' or 'CHW'.
            Default: 'HWC'.
        test_y_channel (bool): Test on Y channel of YCbCr. Default: False.

    Returns:
        float: ssim result.
    """

    assert img3.shape == img2.shape, (
        f'Image shapes are differnet: {img3.shape}, {img2.shape}.')
    if input_order not in ['HWC', 'CHW']:
        raise ValueError(
            f'Wrong input_order {input_order}. Supported input_orders are '
            '"HWC" and "CHW"')
    img3 = reorder_image(img3, input_order=input_order)
    img2 = reorder_image(img2, input_order=input_order)
    img3 = img3.astype(np.float64)
    img2 = img2.astype(np.float64)

    if crop_border != 0:
        img3 = img3[crop_border:-crop_border, crop_border:-crop_border, ...]
        img2 = img2[crop_border:-crop_border, crop_border:-crop_border, ...]

    if test_y_channel:
        img3 = to_y_channel(img3)
        img2 = to_y_channel(img2)

    ssims = []
    for i in range(img3.shape[2]):
        ssims.append(_ssim(img3[..., i], img2[..., i]))
    return np.array(ssims).mean()


def calculate_lpips_out_gt(img1,
                          img2,
                          img3,
                            lq_path,
                          crop_border,
                          input_order='HWC',
                          test_y_channel=False
                          ):

    ## Initializing the model

    if crop_border != 0:
        img1 = img1[crop_border:-crop_border, crop_border:-crop_border, ...]
        img2 = img2[crop_border:-crop_border, crop_border:-crop_border, ...]

    if test_y_channel:
        img1 = to_y_channel(img1)
        img2 = to_y_channel(img2)

    # Load images
    img1 = lpips.im2tensor(img1)  # RGB image from [-1,1]
    img2 = lpips.im2tensor(img2)

    img1 = img1.cuda()
    img2 = img2.cuda()

    # Compute distance
    dist01 = loss_fn.forward(img1, img2)
    dist01 = float('%.6f' % dist01)

    return dist01

def calculate_lpips_in_gt(img1,
                          img2,
                          img3,
                            lq_path,
                          crop_border,
                          input_order='HWC',
                          test_y_channel=False
                          ):

    ## Initializing the model

    if crop_border != 0:
        img3 = img3[crop_border:-crop_border, crop_border:-crop_border, ...]
        img2 = img2[crop_border:-crop_border, crop_border:-crop_border, ...]

    if test_y_channel:
        img3 = to_y_channel(img3)
        img2 = to_y_channel(img2)

    # Load images
    img3 = lpips.im2tensor(img3)  # RGB image from [-1,1]
    img2 = lpips.im2tensor(img2)

    img3 = img3.cuda()
    img2 = img2.cuda()

    # Compute distance
    dist01 = loss_fn.forward(img3, img2)
    dist01 = float('%.6f' % dist01)

    return dist01

def calculate_dists_out_gt(img1,
                          img2,
                          img3,
                            lq_path,
                          crop_border,
                          input_order='HWC',
                          test_y_channel=False
                          ):

    dists_metric = DISTS()

    if crop_border != 0:
        img1 = img1[crop_border:-crop_border, crop_border:-crop_border, ...]
        img2 = img2[crop_border:-crop_border, crop_border:-crop_border, ...]

    if test_y_channel:
        img1 = to_y_channel(img1)
        img2 = to_y_channel(img2)

    img1 = lpips.im2tensor(img1)  # RGB image from [-1,1]
    img2 = lpips.im2tensor(img2)

    img1 = img1.cuda()
    img2 = img2.cuda()

    # Compute distance
    out = dists_metric(img1, img2)
    dist01 = float('%.6f' % out)

    return dist01


def calculate_dists_in_gt(img1,
                           img2,
                           img3,
                           lq_path,
                           crop_border,
                           input_order='HWC',
                           test_y_channel=False
                           ):

    dists_metric = DISTS()

    if crop_border != 0:
        img3 = img3[crop_border:-crop_border, crop_border:-crop_border, ...]
        img2 = img2[crop_border:-crop_border, crop_border:-crop_border, ...]

    if test_y_channel:
        img3 = to_y_channel(img3)
        img2 = to_y_channel(img2)

    img2 = lpips.im2tensor(img2)  # RGB image from [-1,1]
    img3 = lpips.im2tensor(img3)

    img2 = img2.cuda()
    img3 = img3.cuda()

    # Compute distance
    out = dists_metric(img2, img3)
    dist01 = float('%.6f' % out)

    return dist01