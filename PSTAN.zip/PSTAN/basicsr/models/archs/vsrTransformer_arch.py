
#   <<<<<<<<<<<<<<<<  PSTAN based on vsrtransformer >>>>>>>>>>>>>>>   #
# '''
import torch
from torch import nn as nn
from torch.nn import functional as F

import numpy as np
from basicsr.models.archs.arch_util import (ResidualBlockNoBN, make_layer, RCAB, ResidualGroup, default_conv,
                                            RCABWithInputConv)
from einops import rearrange, repeat
from einops.layers.torch import Rearrange
from positional_encodings.torch_encodings import PositionalEncodingPermute3D
from torch.nn import init
import math
from torch import einsum
from basicsr.models.archs.spynet import SPyNet, SPyNetBasicModule, ResidualBlocksWithInputConv
from mmcv.cnn import ConvModule
from mmcv.runner import load_checkpoint
from mmedit.models.common import (PixelShufflePack, flow_warp)  # make_layer
from mmedit.models.registry import BACKBONES
from mmedit.utils import get_root_logger
import pdb

from .arch_util import DCNv2Pack, ResidualBlockNoBN, make_layer

# Transformer
class Residual(nn.Module):
    def __init__(self, fn):
        super().__init__()
        self.fn = fn

    def forward(self, x, **kwargs):
        return self.fn(x, **kwargs) + x


class PreNorm(nn.Module):
    def __init__(self, num_feat, feat_size, fn):
        super().__init__()
        # self.norm = nn.LayerNorm([num_feat, feat_size, feat_size])
        self.fn = fn

    def forward(self, x, **kwargs):
        # return self.fn(self.norm(x), **kwargs)
        return self.fn(nn.LayerNorm([x.shape[-3], x.shape[-2], x.shape[-1]]).to(x.device)(x), **kwargs)

class PreNorm1(nn.Module):
    def __init__(self, ):
        super().__init__()

    def forward(self, x, **kwargs):
        return self.fn(nn.LayerNorm([x.shape[-3], x.shape[-2], x.shape[-1]]).to(x.device)(x), **kwargs)

# feature fusiom
class Fussion(nn.Module):
    """Residual block without BN.

    It has a style of:
        ---Conv-ReLU-Conv-+-
         |________________|

    Args:
        num_feat (int): Channel number of intermediate features.
            Default: 64.
        res_scale (float): Residual scale. Default: 1.
        pytorch_init (bool): If set to True, use pytorch default init,
            otherwise, use default_init_weights. Default: False.
    """

    def __init__(self, num_feat=64):
        super(Fussion, self).__init__()

        self.conv1 = nn.Conv2d(num_feat, num_feat, 3, 1, 1, bias=True)
        self.conv2 = nn.Conv2d(num_feat, num_feat, 3, 1, 1, bias=True)

        self.conv3 = nn.Conv2d(num_feat, num_feat // 2, 3, 1, 1, bias=True)
        self.conv4 = nn.Conv2d(num_feat // 2, num_feat, 3, 1, 1, bias=True)

        self.global_avg_pool = nn.AdaptiveAvgPool2d((1, 1))
        self.conv5 = nn.Conv2d(num_feat, num_feat, 1, 1, 0, bias=True)

        self.BN = nn.BatchNorm2d(num_feat)
        self.BN_1 = nn.BatchNorm2d(num_feat // 2)

    def forward(self, x1, x2):
        b, t, c, h, w = x1.shape
        x1 = x1.contiguous().view(-1, c, h, w)
        x2 = x2.contiguous().view(-1, c, h, w)

        fusion_1 = x1 + x2  # [1, 5, 64, 128, 128 ]
        fusion_1 = fusion_1.view(-1, c, h, w)  # [5, 64, 128, 128 ]

        feature_1 = F.leaky_relu(self.BN(self.conv1(fusion_1)))
        feature_1 = F.leaky_relu(self.BN(self.conv2(feature_1)))  # [5, 64, 128, 128 ]

        feature_2 = self.global_avg_pool(fusion_1)  # [5, 64, 1, 1 ]
        feature_2 = F.leaky_relu(self.BN_1(self.conv3(feature_2)))  # [5, 32, 1, 1 ]
        feature_2 = F.sigmoid(self.BN(self.conv4(feature_2)))  # [5, 64, 1, 1 ]

        feature_3 = F.leaky_relu(self.BN(self.conv5(fusion_1)))
        feature_3 = F.leaky_relu(self.BN(self.conv5(feature_3)))

        fusion_out = feature_1 + torch.mul(x1, feature_2) + torch.mul(x2, feature_2) + feature_3
        fusion_out = fusion_out.view(b, t, c, h, w)

        return fusion_out

    # 将输出恢复为原图像形状

class Self_Attention_Module(nn.Module):
    def __init__(self, in_channels = 64, out_channels = 64):
        super(Self_Attention_Module, self).__init__()
        self.query_conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)
        self.key_conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)
        self.value_conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1)
        self.lrelu = nn.LeakyReLU(negative_slope=0.1, inplace=True)
        self.feat2patch = torch.nn.Unfold(kernel_size=8, padding=0, stride=8)
        # self.patch2feat = torch.nn.Fold(output_size=(128, 128), kernel_size=8, padding=0, stride=8)
        self.conv_first = nn.Conv2d(64, 64, 3, 1, 1)

    def forward(self, x):

        b, c, h, w = x.shape

        x1 = x

        Q = self.query_conv(x1)  # [B, C, H, W]
        K = self.key_conv(x1)  # [B, C, H, W]
        V = self.value_conv(x1)  # [B, C, H, W]

        Q = self.feat2patch(Q)
        K = self.feat2patch(K)
        V = self.feat2patch(V)

        attention = torch.matmul(Q.transpose(1, 2), K)  # [B, N1, N2]
        attention = attention / (Q.size(1) ** 0.5)  

        attention = F.softmax(attention, dim=-1)

        out = torch.matmul(attention, V.transpose(1, 2))  # [B, N1, C]

        out = torch.nn.Fold(output_size=(h, w), kernel_size=8, padding=0, stride=8)(out.transpose(1, 2))
        out = self.conv(out)
        # out = out.transpose(1, 2).contiguous().view(x1.size(0), x1.size(1), x1.size(2), x1.size(3))

        return out

class TMAM(nn.Module):
    def __init__(self, in_channels = 64, out_channels = 64):
        super(TMAM, self).__init__()

        self.query_conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)
        self.key_conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)
        self.value_conv = nn.Conv2d(in_channels, out_channels, kernel_size=1)
        self.conv = nn.Conv2d(in_channels, out_channels, kernel_size=3, stride=1, padding=1)
        self.lrelu = nn.LeakyReLU(negative_slope=0.1, inplace=True)
        self.feat2patch = torch.nn.Unfold(kernel_size=8, padding=0, stride=8)
        # self.patch2feat = torch.nn.Fold(output_size=(128, 128), kernel_size=8, padding=0, stride=8)
        self.conv_first = nn.Conv2d(64, 64, 3, 1, 1)

        self.self_attention = Self_Attention_Module()

    def forward(self, x):

        b, t, c, h, w = x.shape
        self.center_frame_idx = t // 2

        aligned_feat_IFMA = []

        x = self.lrelu(self.conv_first(x.view(-1, c, h, w)))
        x = x.view(b, t, -1, h, w)
        x1 = x[:, self.center_frame_idx, :, :, :].contiguous()

        x1_atten = self.self_attention(x1)

        for i in range(t):
            x2 = x[:, i, :, :, :]

            Q = self.query_conv(x1)  # [B, C, H, W]
            K = self.key_conv(x2)  # [B, C, H, W]
            V = self.value_conv(x2)  # [B, C, H, W]

            Q = self.feat2patch(Q)
            K = self.feat2patch(K)
            V = self.feat2patch(V)

            attention = torch.matmul(Q.transpose(1, 2), K)  # [B, N1, N2]
            attention = attention / (Q.size(1) ** 0.5)  

            attention = F.softmax(attention, dim=-1)

            out = torch.matmul(attention, V.transpose(1, 2))  # [B, N1, C]

            out = torch.nn.Fold(output_size=(h, w), kernel_size=8, padding=0, stride=8)(out.transpose(1, 2))
            out = self.conv(out)
            # out = out.transpose(1, 2).contiguous().view(x1.size(0), x1.size(1), x1.size(2), x1.size(3))
            out = out + x1_atten + x1

            aligned_feat_IFMA.append(out)

        aligned_feat_atten = torch.stack(aligned_feat_IFMA, dim=1)

        return aligned_feat_atten

class Identity(nn.Module):
    def __init__(self):
        super().__init__()

    def forward(self, x):
        return x

class CDCA(nn.Module):

    def __init__(self, num_feat=64, deformable_groups=8):
        super(CDCA, self).__init__()

        self.offset_conv1 = nn.Conv2d(num_feat * 2, num_feat, 3, 1, 1)

        self.dcn_pack = DCNv2Pack(num_feat, num_feat, 3, padding=1, deformable_groups=deformable_groups)

        # Cascading dcn
        self.cas_offset_conv1 = nn.Conv2d(num_feat * 2, num_feat, 3, 1, 1)
        self.cas_offset_conv2 = nn.Conv2d(num_feat, num_feat, 3, 1, 1)
        self.cas_dcnpack = DCNv2Pack(num_feat, num_feat, 3, padding=1, deformable_groups=deformable_groups)

        self.lrelu = nn.LeakyReLU(negative_slope=0.1, inplace=True)
        self.conv_first = nn.Conv2d(64, num_feat, 3, 1, 1)

        # Alignment module
        # self.alig_fusiom = Fussion()

    def forward(self, x, lrs=None, flows=None):

        b, t, c, h, w = x.shape
        self.center_frame_idx = t // 2

        aligned_feat_DConv = []

        x = self.lrelu(self.conv_first(x.view(-1, c, h, w)))
        x = x.view(b, t, -1, h, w)
        ref_feat_l = x[:, self.center_frame_idx, :, :, :].contiguous()

        for i in range(t):
            nbr_feat_l = x[:, i, :, :, :]

            level = f'l{3}'
            offset = torch.cat([nbr_feat_l, ref_feat_l], dim=1)
            offset = self.lrelu(self.offset_conv1(offset))

            feat = self.dcn_pack(nbr_feat_l, offset)
            feat = self.lrelu(feat)

            # Cascading
            offset = torch.cat([feat, ref_feat_l], dim=1)
            offset = self.lrelu(self.cas_offset_conv2(self.lrelu(self.cas_offset_conv1(offset))))
            feat = self.lrelu(self.cas_dcnpack(feat, offset))  # [1, 64, 128, 128]

            aligned_feat_DConv.append(feat)

            # # Intre-Frame Mutual Attention
            #
            # feat_atten = self.cross_attention(ref_feat_l, nbr_feat_l)
            # aligned_feat_IFMA.append(feat_atten)

        aligned_feat_DC = torch.stack(aligned_feat_DConv, dim=1)  # [1 ,5 ,64, 128, 128]

        # aligned_feat = self.alig_fusiom(aligned_feat_DC, aligned_feat_atten)

        return aligned_feat_DC

class FeedForward(nn.Module):
    def __init__(self, num_feat):
        super().__init__()

        self.backward_resblocks = ResidualBlocksWithInputConv(num_feat + 3, num_feat, num_blocks=30)
        self.forward_resblocks = ResidualBlocksWithInputConv(num_feat + 3, num_feat, num_blocks=30)
        self.fusion = nn.Conv2d(num_feat * 2, num_feat, 1, 1, 0, bias=True)
        self.lrelu = nn.LeakyReLU(negative_slope=0.1, inplace=True)

    def forward(self, x, lrs=None, flows=None):
        b, t, c, h, w = x.shape
        x1 = torch.cat([x[:, 1:, :, :, :], x[:, -1, :, :, :].unsqueeze(1)], dim=1)  # [B, 5, 64, 64, 64]
        flow1 = flows[1].contiguous().view(-1, 2, h, w).permute(0, 2, 3, 1)  # [B*5, 64, 64, 2]
        x1 = flow_warp(x1.view(-1, c, h, w), flow1)  # [B*5, 64, 64, 64]
        x1 = torch.cat([lrs.view(b * t, -1, h, w), x1], dim=1)  # [B*5, 67, 64, 64]
        x1 = self.backward_resblocks(x1)  # [B*5, 64, 64, 64]

        x2 = torch.cat([x[:, 0, :, :, :].unsqueeze(1), x[:, :-1, :, :, :]], dim=1)  # [B, 5, 64, 64, 64]
        flow2 = flows[0].contiguous().view(-1, 2, h, w).permute(0, 2, 3, 1)  # [B*5, 64, 64, 2]
        x2 = flow_warp(x2.view(-1, c, h, w), flow2)  # [B*5, 64, 64, 64]
        x2 = torch.cat([lrs.view(b * t, -1, h, w), x2], dim=1)  # [B*5, 67, 64, 64]
        x2 = self.forward_resblocks(x2)  # [B*5, 64, 64, 64]

        # fusion the backward and forward features
        out = torch.cat([x1, x2], dim=1)  # [B*5, 128, 64, 64]
        out = self.lrelu(self.fusion(out))  # [B*5, 64, 64, 64]
        out = out.view(x.shape)  # [B, 5, 64, 64, 64]

        return out

class MatmulNet(nn.Module):
    def __init__(self) -> None:
        super(MatmulNet, self).__init__()

    def forward(self, x: torch.Tensor, y: torch.Tensor) -> torch.Tensor:
        x = torch.matmul(x, y)
        return x

class PSTIM(nn.Module):
    def __init__(self, ):
        super(PSTIM, self).__init__()
        self.conc3d_space_0_0= nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))
        self.conc3d_space_0_1 = nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))
        self.conc3d_space_0_2= nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))
        self.conc3d_space_0_3 = nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))
        self.conc3d_space_out_0 = nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))
        self.conc3d_space_out_1 = nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))
        self.conc3d_space_out_2 = nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))
        self.conc3d_space_out_3 = nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))

        self.space_dowm_1 = nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1))
        self.space_dowm_2 = nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1))
        self.space_dowm_3 = nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1))
        self.space_dowm_1_11 = nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1))
        self.space_dowm_2_11 = nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1))
        self.space_dowm_3_11 = nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1))
        self.space_dowm = nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1))
        self.space_dowm = nn.Conv3d(64, 64, (1, 3, 3), stride=(1, 2, 2), padding=(0, 1, 1))

        self.time_down_0_1 = nn.Conv3d(64, 64, (2, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))
        self.time_down_1_1 = nn.Conv3d(64, 64, (2, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))
        self.time_down_2_1 = nn.Conv3d(64, 64, (2, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))
        self.time_down_3_1 = nn.Conv3d(64, 64, (2, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))
        self.time_down_2_up_1 = nn.Conv3d(64, 64, (2, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))
        self.time_down_1_up_1 = nn.Conv3d(64, 64, (2, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))
        self.time_down_0_up_1 = nn.Conv3d(64, 64, (2, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))
        self.time_down_end = nn.Conv3d(64, 64, (2, 3, 3), stride=(1, 1, 1), padding=(0, 1, 1))

        self.space_time_3_11_up = nn.ConvTranspose3d(64, 64, (1, 4, 4), stride=(1, 2, 2), padding=(0, 1, 1))
        self.space_time_2_11_up = nn.ConvTranspose3d(64, 64, (1, 4, 4), stride=(1, 2, 2), padding=(0, 1, 1))
        self.space_time_1_11_up = nn.ConvTranspose3d(64, 64, (1, 4, 4), stride=(1, 2, 2), padding=(0, 1, 1))
        self.space_time_2_up = nn.ConvTranspose3d(64, 64, (1, 4, 4), stride=(1, 2, 2), padding=(0, 1, 1))
        self.space_time_1_up = nn.ConvTranspose3d(64, 64, (1, 4, 4), stride=(1, 2, 2), padding=(0, 1, 1))
        self.space_time_0_up = nn.ConvTranspose3d(64, 64, (1, 4, 4), stride=(1, 2, 2), padding=(0, 1, 1))
        self.LRelu = nn.LeakyReLU(negative_slope=0.1, inplace=True)

    def forward(self, x):

        b, t, c, h, w = x.shape  # [1, 5, 64, 128, 128]
        x = x.transpose(1, 2)  # [1, 64, 5, 128, 128]
        x_center = x[:, :, t//2, :, :]

        buffer = []
        for i in range(t):
            if i <= t//2:

                x_input = torch.stack((x[:, :, i, :, :], x_center), dim=2)      # [1, 64, 2, 128, 128]
                x_0 = self.LRelu(self.conc3d_space_0_0(x_input))  # [1, 64, 2, 128, 128]
                x_0 = self.LRelu(self.conc3d_space_0_1(x_0))  # [1, 64, 2, 128, 128]
                x_0 = self.LRelu(self.conc3d_space_0_2(x_0))  # [1, 64, 2, 128, 128]

                x_0 = self.LRelu(self.conc3d_space_0_3(x_0))  # [1, 64, 2, 128, 128]
                x_1 = self.LRelu(self.space_dowm_1(x_0))  # [1, 64, 2, 64, 64]
                x_2 = self.LRelu(self.space_dowm_2(x_1))  # [1, 64, 2, 32, 32]
                x_3 = self.LRelu(self.space_dowm_3(x_2))  # [1, 64, 2, 16, 16]

                x_0_1 = self.LRelu(self.time_down_0_1(x_0))  # [1, 64, 1, 128, 128]
                x_1_1 = self.LRelu(self.time_down_1_1(x_1))  # [1, 64, 1, 64, 64]
                x_2_1 = self.LRelu(self.time_down_2_1(x_2))  # [1, 64, 1, 32, 32]
                x_3_1 = self.LRelu(self.time_down_3_1(x_3))  # [1, 64, 1, 16, 16]

                x_1_11 = self.LRelu(self.space_dowm_1_11(x_0_1))  # [1, 64, 1, 64, 64]
                x_2_11 = self.LRelu(self.space_dowm_2_11(x_1_11 + x_1_1))  # [1, 64, 1, 32, 32]
                x_3_11 = self.LRelu(self.space_dowm_3_11(x_2_11 + x_2_1))  # [1, 64, 1, 16, 16]

                x_3_11_up = self.LRelu(self.space_time_3_11_up(x_3_11))  # # [1, 64, 1, 32, 32]
                x_2_11_up = self.LRelu(self.space_time_2_11_up(x_3_11_up))  # # [1, 64, 1, 64, 64]
                x_1_11_up = self.LRelu(self.space_time_1_11_up(x_2_11_up))  # # [1, 64, 1, 128, 128]

                x_2_up = self.LRelu(self.space_time_2_up(x_3))  # [1, 64, 2, 32, 32]
                x_2_up_1 = self.LRelu(self.time_down_2_up_1(x_2_up))  # [1, 64, 1, 32, 32]

                x_1_up = self.LRelu(self.space_time_1_up(
                    torch.concat((x_2_up_1 + x_3_11_up, x_2_1), dim=2) + x_2_up))  # [1, 64, 2, 64, 64]
                x_1_up_1 = self.LRelu(self.time_down_1_up_1(x_1_up))  # [1, 64, 1, 64, 64]

                x_0_up = self.LRelu(self.space_time_0_up(
                    torch.concat((x_1_up_1 + x_2_11_up, x_1_1), dim=2) + x_1_up))  # [1, 64, 2, 128, 128]
                x_0_up_1 = self.LRelu(self.time_down_0_up_1(x_0_up))  # [1, 64, 1, 128, 128]

                x_out = self.LRelu(self.conc3d_space_out_0(
                    torch.concat((x_0_up_1 + x_1_11_up, x_0_1), dim=2) + x_0_up))  # [1, 64, 2, 128, 128]
                x_out = self.LRelu(self.conc3d_space_out_1(x_out))
                x_out = self.LRelu(self.conc3d_space_out_2(x_out))
                x_out = self.LRelu(self.conc3d_space_out_3(x_out))

            else:
                x_input = torch.stack((x[:, :, i, :, :], x_center), dim=2)  # [1, 64, 2, 128, 128]
                x_0 = self.LRelu(self.conc3d_space_0_0(x_input))  # [1, 64, 2, 128, 128]
                x_0 = self.LRelu(self.conc3d_space_0_1(x_0))  # [1, 64, 2, 128, 128]
                x_0 = self.LRelu(self.conc3d_space_0_2(x_0))  # [1, 64, 2, 128, 128]

                x_0 = self.LRelu(self.conc3d_space_0_3(x_0))  # [1, 64, 2, 128, 128]
                x_1 = self.LRelu(self.space_dowm_1(x_0))  # [1, 64, 2, 64, 64]
                x_2 = self.LRelu(self.space_dowm_2(x_1))  # [1, 64, 2, 32, 32]
                x_3 = self.LRelu(self.space_dowm_3(x_2))  # [1, 64, 2, 16, 16]

                x_0_1 = self.LRelu(self.time_down_0_1(x_0))  # [1, 64, 1, 128, 128]
                x_1_1 = self.LRelu(self.time_down_1_1(x_1))  # [1, 64, 1, 64, 64]
                x_2_1 = self.LRelu(self.time_down_2_1(x_2))  # [1, 64, 1, 32, 32]
                x_3_1 = self.LRelu(self.time_down_3_1(x_3))  # [1, 64, 1, 16, 16]

                x_1_11 = self.LRelu(self.space_dowm_1_11(x_0_1))  # [1, 64, 1, 64, 64]
                x_2_11 = self.LRelu(self.space_dowm_2_11(x_1_11 + x_1_1))  # [1, 64, 1, 32, 32]
                x_3_11 = self.LRelu(self.space_dowm_3_11(x_2_11 + x_2_1))  # [1, 64, 1, 16, 16]

                x_3_11_up = self.LRelu(self.space_time_3_11_up(x_3_11))  # # [1, 64, 1, 32, 32]
                x_2_11_up = self.LRelu(self.space_time_2_11_up(x_3_11_up))  # # [1, 64, 1, 64, 64]
                x_1_11_up = self.LRelu(self.space_time_1_11_up(x_2_11_up))  # # [1, 64, 1, 128, 128]

                x_2_up = self.LRelu(self.space_time_2_up(x_3))  # [1, 64, 2, 32, 32]
                x_2_up_1 = self.LRelu(self.time_down_2_up_1(x_2_up))  # [1, 64, 1, 32, 32]

                x_1_up = self.LRelu(self.space_time_1_up(
                    torch.concat((x_2_up_1 + x_3_11_up, x_2_1), dim=2) + x_2_up))  # [1, 64, 2, 64, 64]
                x_1_up_1 = self.LRelu(self.time_down_1_up_1(x_1_up))  # [1, 64, 1, 64, 64]

                x_0_up = self.LRelu(self.space_time_0_up(
                    torch.concat((x_1_up_1 + x_2_11_up, x_1_1), dim=2) + x_1_up))  # [1, 64, 2, 128, 128]
                x_0_up_1 = self.LRelu(self.time_down_0_up_1(x_0_up))  # [1, 64, 1, 128, 128]

                x_out = self.LRelu(self.conc3d_space_out_0(
                    torch.concat((x_0_up_1 + x_1_11_up, x_0_1), dim=2) + x_0_up))  # [1, 64, 2, 128, 128]
                x_out = self.LRelu(self.conc3d_space_out_1(x_out))
                x_out = self.LRelu(self.conc3d_space_out_2(x_out))
                x_out = self.LRelu(self.conc3d_space_out_3(x_out))

            x_out = self.LRelu(self.time_down_end(x_out))

            buffer.append(x_out)

        out = torch.concat(buffer,dim=2)
        out += x
        out = out.transpose(1, 2).contiguous()

        return out

class Transformer(nn.Module):
    def __init__(self, num_feat, feat_size, depth, patch_size, heads):
        super().__init__()
        self.layers = nn.ModuleList([])

        # #  ---------------------- all model ---------------------  #
        for _ in range(depth):
            self.layers.append(nn.ModuleList([
                Residual(PreNorm(num_feat, feat_size, TMAM())),
                Residual(PreNorm(num_feat, feat_size, CDCA()))
            ]))

    def forward(self, x, lrs=None, flows=None):
        for attn,ff in self.layers:
            x = attn(x)     
            x = ff(x, lrs=lrs, flows=flows)
        return x

class vsrTransformer(nn.Module):
    def __init__(self,
                 image_ch=3,
                 num_feat=64,
                 # feat_size=64,
                 # feat_size=64,
                 feat_size=128,
                 num_frame=5,
                 num_extract_block=5,
                 num_reconstruct_block=30,
                 depth=10,
                 heads=1,
                 patch_size=8,
                 spynet_pretrained=None
                 ):
        super(vsrTransformer, self).__init__()
        self.num_reconstruct_block = num_reconstruct_block
        self.center_frame_idx = num_frame // 2
        self.num_frame = num_frame

        # Feature extractor
        self.conv_first = nn.Conv2d(image_ch, num_feat, 3, 1, 1)
        self.feature_extraction = make_layer(ResidualBlockNoBN, num_extract_block, num_feat=num_feat)
        self.lrelu = nn.LeakyReLU(negative_slope=0.1, inplace=True)

        # MSIFAM
        self.PSTIM = PSTIM()

        # Transformer
        self.pos_embedding = PositionalEncodingPermute3D(num_frame)
        self.transformer = Transformer(num_feat, feat_size, depth, patch_size, heads)

        # Reconstruction
        self.reconstruction = make_layer(ResidualBlockNoBN, num_reconstruct_block, num_feat=num_feat)
        self.conv_last = nn.Conv2d(num_feat, image_ch, 3, 1, 1)
        self.fusion = nn.Conv2d(num_frame * num_feat, num_feat, 1, 1)

    def forward(self, x):
        b, t, c, h, w = x.size()  # [B, 5, 3, 64, 64]
        assert h % 4 == 0 and w % 4 == 0, ('w and h must be multiple of 4')

        # extract features for each frame
        feat = self.lrelu(self.conv_first(x.view(-1, c, h, w)))  # [B*5, 64, 64, 64]
        feat1 = self.feature_extraction(feat).view(b, t, -1, h, w)  # [B, 5, 64, 64, 64]

        # PSTIM
        feat2 = self.PSTIM(feat1)

        # transformer
        # feat_fusion = feat1 + self.pos_embedding(feat1)  # [B, 5, 64, 64, 64]   # w / o MSIFAM
        feat_fusion = feat2 + self.pos_embedding(feat2)  # [B, 5, 64, 64, 64]
        tr_feat = self.transformer(feat_fusion, x, None)  # [B, 5, 64, 64, 64]

        # fusion
        aligned_feat = tr_feat.view(b, -1, h, w)
        feat = self.fusion(aligned_feat)

        # reconstruction
        feat = self.reconstruction(feat)  # [B, 64, 64, 64]   -> [B*5, 64, 64, 64]
        out = self.conv_last(feat)  # [B, 3, 256, 256]  -> [B*5, 3, 256, 256]

        # residual
        base = x[:, self.center_frame_idx, :, :, :].contiguous()
        out += base  # [B*5, 3, 256, 256]

        return out


def initialize_weights(net_l, scale=0.1):
    if not isinstance(net_l, list):
        net_l = [net_l]
    for net in net_l:
        for m in net.modules():
            if isinstance(m, nn.Conv3d):
                init.kaiming_normal_(m.weight, a=0, mode='fan_in')
                m.weight.data *= scale
                if m.bias is not None:
                    m.bias.data.zero_()
            elif isinstance(m, nn.Linear):
                init.kaiming_normal_(m.weight, a=0, mode='fan_in')
                m.weight.data *= scale
                if m.bias is not None:
                    m.bias.data.zero_()
